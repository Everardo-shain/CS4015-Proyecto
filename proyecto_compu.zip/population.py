from newindiv import *

def population(n,c_len):
    pop =[]
    for i in range(0,n):
        pop.append(newindiv(c_len))
    return pop    
    
